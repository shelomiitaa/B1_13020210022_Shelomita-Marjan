/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javautilscanne;

/**
 *
 * @author Asus
 */
public class asign {
    public static void main(String[] args) {
        int i;
        
        System.out.print ("hello\n"); i=5;
        System.out.println("Ini nilai i : "+ i);
    }
    
}

