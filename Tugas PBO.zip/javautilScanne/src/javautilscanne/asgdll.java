/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javautilscanne;

/**
 *
 * @author Asus
 */
public class asgdll {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        /* Kamus */
        float f= 20.0f;
        double fll;
        
        /* Algoritma */
        fll=10.0f;
        System.out.println ("f : " +f+ "\nfll: "+fll);
        
    }
}
