/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javautilscanne;

/**
 *
 * @author Asus
 */
public class Open3 {
 public static void main(String[] args) {
        // TODO Auto-generated method stub
        /* Algoritma */
        if (true && true){ System.out.println(true && true); }      /* true = true and true */
        if (true & true) { System.out.println(true & false); }      /* true & true */
        if (true) { System.out.println(true); }                     /* true */
        if (true || true){ System.out.println(true); }              /* true = true or true */
        if (true|false) { System.out.println(true|false); }         /* true|false */
        
    }    
}
